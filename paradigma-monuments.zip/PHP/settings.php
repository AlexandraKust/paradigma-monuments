<?php

$sender = 'no-reply@example.com'; //отправитель (указать доменную почту) домен: example.com => почта no-reply@example.com
$recipient = 'example@example.com'; //получатель
$site_name = 'Masterskaya granita';

?>